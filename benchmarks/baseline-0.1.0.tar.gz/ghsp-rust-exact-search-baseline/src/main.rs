//! Exact finite Gromov--Hausdorff correspondence search.
//!
//! This is a compiled experimental counterpart to the small Python oracle in
//! `.research-scratch`. It uses dynamic bitsets, lazy compatibility masks,
//! binary search over distortion thresholds, and subset DP for Hausdorff
//! metrics. It is still exponential in the worst case.

use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::env;
use std::fmt::Write as FmtWrite;
use std::io::Write as IoWrite;
use std::process::{Command, ExitCode, Stdio};
use std::time::Instant;

const KNOWN_LEFT: [u32; 6] = [215, 886, 318, 912, 396, 1191];
const KNOWN_RIGHT: [u32; 6] = [210, 593, 506, 787, 707, 92];
const DEFAULT_MAX_HYPERSPACE_POINTS: usize = 127;
const DEFAULT_MAX_RELATION_VERTICES: usize = 20_000;
const DEFAULT_MAX_LAZY_DEPTH: usize = 4_095;
const DEFAULT_MAX_SEARCH_NODES: u64 = 2_000_000;
const DEFAULT_MAX_CANDIDATE_SCANS: u64 = 100_000_000;
const DEFAULT_MAX_DISTANCE_CACHE: usize = 4_000_000;
const DEFAULT_MRV_WINDOW: usize = 8;
const DEFAULT_MAX_ULTRAMETRIC_BLOCKS: usize = 24;
const DEFAULT_MAX_ULTRAMETRIC_ASSIGNMENTS: u64 = 5_000_000;
const DEFAULT_MAX_Z3_VARIABLES: usize = 5_000;
const DEFAULT_MAX_Z3_CLAUSES: u64 = 10_000_000;
const DEFAULT_Z3_TIMEOUT_SECONDS: u64 = 30;
const AUTO_Z3_MIN_RELATION_VERTICES: usize = 226;
const AUTO_Z3_RELATION_VERTICES: usize = 1_500;

#[derive(Clone, Debug, Eq, PartialEq)]
struct Metric {
    order: usize,
    entries: Vec<u32>,
}

impl Metric {
    fn from_edges(edges: &[u32]) -> Result<Self, String> {
        let order = infer_order(edges.len())?;
        let mut entries = vec![0; order * order];
        let mut cursor = 0;
        for i in 0..order {
            for j in (i + 1)..order {
                let value = edges[cursor];
                if value == 0 {
                    return Err(format!("edge {i}-{j} has zero length"));
                }
                entries[i * order + j] = value;
                entries[j * order + i] = value;
                cursor += 1;
            }
        }
        let metric = Self { order, entries };
        metric.validate()?;
        Ok(metric)
    }

    fn get(&self, i: usize, j: usize) -> u32 {
        self.entries[i * self.order + j]
    }

    fn from_rule(order: usize, rule: impl Fn(usize, usize) -> u32) -> Result<Self, String> {
        let mut entries = vec![0; order * order];
        for i in 0..order {
            for j in (i + 1)..order {
                let value = rule(i, j);
                entries[i * order + j] = value;
                entries[j * order + i] = value;
            }
        }
        let metric = Self { order, entries };
        metric.validate()?;
        Ok(metric)
    }

    fn validate(&self) -> Result<(), String> {
        for i in 0..self.order {
            if self.get(i, i) != 0 {
                return Err(format!("diagonal entry {i},{i} is not zero"));
            }
            for j in 0..self.order {
                if self.get(i, j) != self.get(j, i) {
                    return Err(format!("entries {i},{j} and {j},{i} differ"));
                }
                if i != j && self.get(i, j) == 0 {
                    return Err(format!("entry {i},{j} is not positive"));
                }
                for k in 0..self.order {
                    if self.get(i, j) > self.get(i, k).saturating_add(self.get(k, j)) {
                        return Err(format!("triangle inequality fails at {i},{k},{j}"));
                    }
                }
            }
        }
        Ok(())
    }

    fn distance_levels(&self) -> BTreeSet<u32> {
        self.entries.iter().copied().collect()
    }

    fn diameter(&self) -> u32 {
        self.entries.iter().copied().max().unwrap_or(0)
    }

    fn radius(&self) -> u32 {
        (0..self.order)
            .map(|i| (0..self.order).map(|j| self.get(i, j)).max().unwrap_or(0))
            .min()
            .unwrap_or(0)
    }

    fn minimum_positive_distance(&self) -> u32 {
        self.entries
            .iter()
            .copied()
            .filter(|value| *value > 0)
            .min()
            .unwrap_or(u32::MAX)
    }

    fn is_ultrametric(&self) -> bool {
        (0..self.order).all(|i| {
            (0..self.order).all(|j| {
                (0..self.order).all(|k| self.get(i, j) <= self.get(i, k).max(self.get(k, j)))
            })
        })
    }

    fn is_equilateral(&self) -> Option<u32> {
        let mut positive = self.entries.iter().copied().filter(|value| *value > 0);
        let first = positive.next()?;
        positive.all(|value| value == first).then_some(first)
    }

    fn component_sizes_leq(&self, threshold: u64) -> Vec<usize> {
        let mut parent: Vec<usize> = (0..self.order).collect();

        fn find(parent: &mut [usize], mut point: usize) -> usize {
            while parent[point] != point {
                parent[point] = parent[parent[point]];
                point = parent[point];
            }
            point
        }

        for i in 0..self.order {
            for j in (i + 1)..self.order {
                if u64::from(self.get(i, j)) <= threshold {
                    let left = find(&mut parent, i);
                    let right = find(&mut parent, j);
                    if left != right {
                        parent[right] = left;
                    }
                }
            }
        }
        let mut counts = BTreeMap::new();
        for point in 0..self.order {
            let root = find(&mut parent, point);
            *counts.entry(root).or_insert(0_usize) += 1;
        }
        let mut result: Vec<usize> = counts.into_values().collect();
        result.sort_unstable();
        result
    }

    fn open_component_labels(&self, threshold: u32) -> Vec<usize> {
        let mut labels = vec![usize::MAX; self.order];
        let mut next_label = 0;
        for seed in 0..self.order {
            if labels[seed] != usize::MAX {
                continue;
            }
            let mut stack = vec![seed];
            labels[seed] = next_label;
            while let Some(point) = stack.pop() {
                for (neighbor, label) in labels.iter_mut().enumerate() {
                    if *label == usize::MAX && self.get(point, neighbor) < threshold {
                        *label = next_label;
                        stack.push(neighbor);
                    }
                }
            }
            next_label += 1;
        }
        labels
    }

    fn mst_merge_spectrum(&self) -> Vec<u32> {
        if self.order <= 1 {
            return Vec::new();
        }
        let mut in_tree = vec![false; self.order];
        let mut best = vec![u32::MAX; self.order];
        best[0] = 0;
        let mut result = Vec::with_capacity(self.order - 1);
        for step in 0..self.order {
            let point = (0..self.order)
                .filter(|i| !in_tree[*i])
                .min_by_key(|i| best[*i])
                .expect("a finite complete metric graph stays connected");
            in_tree[point] = true;
            if step > 0 {
                result.push(best[point]);
            }
            for neighbor in 0..self.order {
                if !in_tree[neighbor] {
                    best[neighbor] = best[neighbor].min(self.get(point, neighbor));
                }
            }
        }
        result.sort_unstable();
        result
    }
}

fn edge_rank(order: usize, i: usize, j: usize) -> usize {
    i * (2 * order - i - 1) / 2 + (j - i)
}

fn family_metric(name: &str, order: usize) -> Result<Metric, String> {
    if !(4..=20).contains(&order) {
        return Err(format!(
            "catalog families are recorded only for orders 4 through 20, received {order}"
        ));
    }
    let normalized = name.replace('-', "_");
    match normalized.as_str() {
        "equilateral" => Metric::from_rule(order, |_i, _j| 1),
        "binary_star" => Metric::from_rule(order, |i, j| (1_u32 << i) + (1_u32 << j)),
        "dyadic_line" => Metric::from_rule(order, |i, j| (1_u32 << i).abs_diff(1_u32 << j)),
        "comb_ultrametric" => Metric::from_rule(order, |_i, j| 1_u32 << j),
        "balanced_ultrametric" => Metric::from_rule(order, |i, j| {
            1_u32 << (usize::BITS - (i ^ j).leading_zeros())
        }),
        "rank_generic" => Metric::from_rule(order, |i, j| 1000 + edge_rank(order, i, j) as u32),
        _ => Err(format!(
            "unknown family {name:?}; choose equilateral, binary_star, \
             dyadic_line, comb_ultrametric, balanced_ultrametric, or rank_generic"
        )),
    }
}

fn infer_order(edge_count: usize) -> Result<usize, String> {
    for order in 2_usize..=1_000_000 {
        match order.checked_mul(order - 1).map(|value| value / 2) {
            Some(count) if count == edge_count => return Ok(order),
            Some(count) if count > edge_count => break,
            Some(_) => {}
            None => break,
        }
    }
    Err(format!(
        "{edge_count} entries are not the edge count n(n-1)/2 of a finite space"
    ))
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct BitSet {
    words: Vec<u64>,
}

impl BitSet {
    fn empty(bit_len: usize) -> Self {
        Self {
            words: vec![0; bit_len.div_ceil(64)],
        }
    }

    fn full(bit_len: usize) -> Self {
        let mut result = Self {
            words: vec![u64::MAX; bit_len.div_ceil(64)],
        };
        if let Some(last) = result.words.last_mut() {
            let remainder = bit_len % 64;
            if remainder != 0 {
                *last = (1_u64 << remainder) - 1;
            }
        }
        result
    }

    fn set(&mut self, bit: usize) {
        self.words[bit / 64] |= 1_u64 << (bit % 64);
    }

    fn clear(&mut self, bit: usize) {
        self.words[bit / 64] &= !(1_u64 << (bit % 64));
    }

    fn contains(&self, bit: usize) -> bool {
        self.words[bit / 64] & (1_u64 << (bit % 64)) != 0
    }

    fn count(&self) -> u64 {
        self.words
            .iter()
            .map(|word| u64::from(word.count_ones()))
            .sum()
    }

    fn intersection(&self, other: &Self) -> Self {
        Self {
            words: self
                .words
                .iter()
                .zip(&other.words)
                .map(|(left, right)| left & right)
                .collect(),
        }
    }

    fn intersection_count(&self, other: &Self) -> u64 {
        self.words
            .iter()
            .zip(&other.words)
            .map(|(left, right)| u64::from((left & right).count_ones()))
            .sum()
    }

    fn pop_first(&mut self) -> Option<usize> {
        for (word_index, word) in self.words.iter_mut().enumerate() {
            if *word != 0 {
                let offset = word.trailing_zeros() as usize;
                *word &= *word - 1;
                return Some(64 * word_index + offset);
            }
        }
        None
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct FailedState {
    candidates: BitSet,
    covered_rows: BitSet,
    covered_columns: BitSet,
}

#[derive(Default, Debug)]
struct FeasibilityStats {
    nodes: u64,
    compatibility_masks_built: u64,
    memo_hits: u64,
    failed_states: usize,
}

struct CorrespondenceSolver<'a> {
    left: &'a Metric,
    right: &'a Metric,
    epsilon: u32,
    vertex_count: usize,
    row_masks: Vec<BitSet>,
    column_masks: Vec<BitSet>,
    compatibility: Vec<Option<BitSet>>,
    failed: HashSet<FailedState>,
    stats: FeasibilityStats,
}

impl<'a> CorrespondenceSolver<'a> {
    fn new(left: &'a Metric, right: &'a Metric, epsilon: u32) -> Result<Self, String> {
        let vertex_count = left
            .order
            .checked_mul(right.order)
            .ok_or_else(|| "relation-vertex count overflowed usize".to_string())?;
        let mut row_masks = vec![BitSet::empty(vertex_count); left.order];
        let mut column_masks = vec![BitSet::empty(vertex_count); right.order];
        for (i, row_mask) in row_masks.iter_mut().enumerate() {
            for (j, column_mask) in column_masks.iter_mut().enumerate() {
                let vertex = i * right.order + j;
                row_mask.set(vertex);
                column_mask.set(vertex);
            }
        }
        Ok(Self {
            left,
            right,
            epsilon,
            vertex_count,
            row_masks,
            column_masks,
            compatibility: vec![None; vertex_count],
            failed: HashSet::new(),
            stats: FeasibilityStats::default(),
        })
    }

    fn solve(mut self) -> (bool, FeasibilityStats) {
        let candidates = BitSet::full(self.vertex_count);
        let covered_rows = BitSet::empty(self.left.order);
        let covered_columns = BitSet::empty(self.right.order);
        let result = self.search(candidates, covered_rows, covered_columns);
        self.stats.failed_states = self.failed.len();
        (result, self.stats)
    }

    fn compatibility_mask(&mut self, vertex: usize) -> BitSet {
        if let Some(mask) = &self.compatibility[vertex] {
            return mask.clone();
        }
        let i = vertex / self.right.order;
        let j = vertex % self.right.order;
        let mut mask = BitSet::empty(self.vertex_count);
        for k in 0..self.left.order {
            for ell in 0..self.right.order {
                if self.left.get(i, k).abs_diff(self.right.get(j, ell)) <= self.epsilon {
                    mask.set(k * self.right.order + ell);
                }
            }
        }
        self.stats.compatibility_masks_built += 1;
        self.compatibility[vertex] = Some(mask.clone());
        mask
    }

    fn search(
        &mut self,
        candidates: BitSet,
        covered_rows: BitSet,
        covered_columns: BitSet,
    ) -> bool {
        self.stats.nodes += 1;
        if covered_rows.count() == self.left.order as u64
            && covered_columns.count() == self.right.order as u64
        {
            return true;
        }

        let state = FailedState {
            candidates: candidates.clone(),
            covered_rows: covered_rows.clone(),
            covered_columns: covered_columns.clone(),
        };
        if self.failed.contains(&state) {
            self.stats.memo_hits += 1;
            return false;
        }

        let mut option_count = u64::MAX;
        let mut options = None;
        for row in 0..self.left.order {
            if covered_rows.contains(row) {
                continue;
            }
            let count = candidates.intersection_count(&self.row_masks[row]);
            if count == 0 {
                self.failed.insert(state);
                return false;
            }
            if count < option_count {
                option_count = count;
                options = Some(candidates.intersection(&self.row_masks[row]));
            }
        }
        for column in 0..self.right.order {
            if covered_columns.contains(column) {
                continue;
            }
            let count = candidates.intersection_count(&self.column_masks[column]);
            if count == 0 {
                self.failed.insert(state);
                return false;
            }
            if count < option_count {
                option_count = count;
                options = Some(candidates.intersection(&self.column_masks[column]));
            }
        }

        let mut options = options.expect("an uncovered row or column must remain");
        while let Some(vertex) = options.pop_first() {
            let i = vertex / self.right.order;
            let j = vertex % self.right.order;
            let compatibility = self.compatibility_mask(vertex);
            let next_candidates = candidates.intersection(&compatibility);
            let mut next_rows = covered_rows.clone();
            let mut next_columns = covered_columns.clone();
            next_rows.set(i);
            next_columns.set(j);
            if self.search(next_candidates, next_rows, next_columns) {
                return true;
            }
        }
        self.failed.insert(state);
        false
    }
}

#[derive(Default, Debug)]
struct ExactStats {
    candidate_thresholds: usize,
    feasibility_checks: u64,
    search_nodes: u64,
    compatibility_masks_built: u64,
    memo_hits: u64,
    failed_states: u64,
}

fn candidate_thresholds(left: &Metric, right: &Metric) -> Vec<u32> {
    let left_levels = left.distance_levels();
    let right_levels = right.distance_levels();
    let mut thresholds = BTreeSet::new();
    for left_value in &left_levels {
        for right_value in &right_levels {
            thresholds.insert(left_value.abs_diff(*right_value));
        }
    }
    thresholds.into_iter().collect()
}

fn labelled_correspondence_upper_bound(left: &Metric, right: &Metric) -> u32 {
    let mut relation = Vec::with_capacity(left.order + right.order);
    for i in 0..left.order {
        relation.push((i, i % right.order));
    }
    for j in 0..right.order {
        relation.push((j % left.order, j));
    }
    relation.sort_unstable();
    relation.dedup();
    relation
        .iter()
        .flat_map(|first| relation.iter().map(move |second| (*first, *second)))
        .map(|((i, j), (k, ell))| left.get(i, k).abs_diff(right.get(j, ell)))
        .max()
        .unwrap_or(0)
}

fn structural_lower_bound(left: &Metric, right: &Metric) -> u32 {
    let target_len = left.order.max(right.order) - 1;
    let mut left_spectrum = vec![0; target_len - (left.order - 1)];
    left_spectrum.extend(left.mst_merge_spectrum());
    let mut right_spectrum = vec![0; target_len - (right.order - 1)];
    right_spectrum.extend(right.mst_merge_spectrum());
    let merge_bound = left_spectrum
        .iter()
        .zip(&right_spectrum)
        .map(|(a, b)| a.abs_diff(*b))
        .max()
        .unwrap_or(0);
    merge_bound
        .max(left.diameter().abs_diff(right.diameter()))
        .max(left.radius().abs_diff(right.radius()))
}

#[derive(Default, Debug)]
struct StructuralStats {
    thresholds_checked: u64,
    lower_bound_rejections: u64,
    cardinality_rejections: u64,
    component_count_rejections: u64,
    component_dominance_rejections: u64,
    subset_product_vectors_built: u64,
}

struct StructuralFilter<'a> {
    left: &'a Metric,
    right: &'a Metric,
    lower_bound: u32,
    subset_products: HashMap<Vec<usize>, Vec<u64>>,
    stats: StructuralStats,
}

impl<'a> StructuralFilter<'a> {
    fn new(left: &'a Metric, right: &'a Metric) -> Self {
        Self {
            left,
            right,
            lower_bound: structural_lower_bound(left, right),
            subset_products: HashMap::new(),
            stats: StructuralStats::default(),
        }
    }

    fn products_for(&mut self, component_sizes: &[usize]) -> Vec<u64> {
        if let Some(products) = self.subset_products.get(component_sizes) {
            return products.clone();
        }
        let mut products = vec![1_u64];
        for size in component_sizes {
            let weight = (1_u64 << size) - 1;
            let additions: Vec<u64> = products.iter().map(|value| value * weight).collect();
            products.extend(additions);
        }
        products.sort_unstable();
        let empty_position = products
            .iter()
            .position(|value| *value == 1)
            .expect("the empty support contributes one");
        products.remove(empty_position);
        self.stats.subset_product_vectors_built += 1;
        self.subset_products
            .insert(component_sizes.to_vec(), products.clone());
        products
    }

    fn dominance_holds(&mut self, source: &[usize], target: &[usize]) -> bool {
        if source == target {
            return true;
        }
        let source_products = self.products_for(source);
        let target_products = self.products_for(target);
        source_products.len() == target_products.len()
            && source_products
                .iter()
                .zip(target_products)
                .all(|(source_value, target_value)| *source_value >= target_value)
    }

    fn accepts(&mut self, epsilon: u32) -> bool {
        self.stats.thresholds_checked += 1;
        if epsilon < self.lower_bound {
            self.stats.lower_bound_rejections += 1;
            return false;
        }
        if (epsilon < self.right.minimum_positive_distance() && self.left.order < self.right.order)
            || (epsilon < self.left.minimum_positive_distance()
                && self.right.order < self.left.order)
        {
            self.stats.cardinality_rejections += 1;
            return false;
        }

        let epsilon64 = u64::from(epsilon);
        let mut events = BTreeSet::from([0_u64]);
        for distance in self
            .left
            .distance_levels()
            .into_iter()
            .chain(self.right.distance_levels())
        {
            let distance64 = u64::from(distance);
            events.insert(distance64);
            if distance64 >= epsilon64 {
                events.insert(distance64 - epsilon64);
            }
        }

        for scale in events {
            let left_now = self.left.component_sizes_leq(scale);
            let right_now = self.right.component_sizes_leq(scale);
            let shifted = scale + epsilon64;
            let left_shifted = self.left.component_sizes_leq(shifted);
            let right_shifted = self.right.component_sizes_leq(shifted);

            if right_shifted.len() > left_now.len() || left_shifted.len() > right_now.len() {
                self.stats.component_count_rejections += 1;
                return false;
            }

            if left_now.len() == right_shifted.len()
                && epsilon < self.right.minimum_positive_distance()
                && !self.dominance_holds(&left_now, &right_shifted)
            {
                self.stats.component_dominance_rejections += 1;
                return false;
            }
            if right_now.len() == left_shifted.len()
                && epsilon < self.left.minimum_positive_distance()
                && !self.dominance_holds(&right_now, &left_shifted)
            {
                self.stats.component_dominance_rejections += 1;
                return false;
            }
        }
        true
    }
}

fn minimum_distortion(
    left: &Metric,
    right: &Metric,
    max_relation_vertices: usize,
) -> Result<(u32, ExactStats), String> {
    let relation_vertices = left
        .order
        .checked_mul(right.order)
        .ok_or_else(|| "relation-vertex count overflowed usize".to_string())?;
    if relation_vertices > max_relation_vertices {
        return Err(format!(
            "refusing {relation_vertices} relation vertices; safety limit is \
             {max_relation_vertices} (override with --max-relation-vertices)"
        ));
    }
    let thresholds = candidate_thresholds(left, right);
    let mut stats = ExactStats {
        candidate_thresholds: thresholds.len(),
        ..ExactStats::default()
    };
    let mut lower = 0;
    let mut upper = thresholds.len() - 1;
    while lower < upper {
        let middle = lower + (upper - lower) / 2;
        let solver = CorrespondenceSolver::new(left, right, thresholds[middle])?;
        let (feasible, run) = solver.solve();
        stats.feasibility_checks += 1;
        stats.search_nodes += run.nodes;
        stats.compatibility_masks_built += run.compatibility_masks_built;
        stats.memo_hits += run.memo_hits;
        stats.failed_states += run.failed_states as u64;
        if feasible {
            upper = middle;
        } else {
            lower = middle + 1;
        }
    }
    Ok((thresholds[lower], stats))
}

fn hyperspace_metric(base: &Metric, max_points: usize) -> Result<Metric, String> {
    let subset_count = 1_usize
        .checked_shl(base.order as u32)
        .ok_or_else(|| "base order is too large for subset masks".to_string())?;
    let point_count = subset_count - 1;
    if point_count > max_points {
        return Err(format!(
            "Exp(X) has {point_count} points; safety limit is {max_points} \
             (override with --max-hyperspace-points)"
        ));
    }
    let entry_count = point_count
        .checked_mul(point_count)
        .ok_or_else(|| "hyperspace distance-matrix size overflowed usize".to_string())?;

    // nearest[i, mask] = d(i, mask), built in O(n 2^n).
    let mut nearest = vec![u32::MAX; base.order * subset_count];
    for point in 0..base.order {
        for mask in 1..subset_count {
            let singleton = mask.trailing_zeros() as usize;
            let remainder = mask & (mask - 1);
            let edge = base.get(point, singleton);
            nearest[point * subset_count + mask] = if remainder == 0 {
                edge
            } else {
                edge.min(nearest[point * subset_count + remainder])
            };
        }
    }

    let directed = |source: usize, target: usize| -> u32 {
        let mut remaining = source;
        let mut maximum = 0;
        while remaining != 0 {
            let point = remaining.trailing_zeros() as usize;
            maximum = maximum.max(nearest[point * subset_count + target]);
            remaining &= remaining - 1;
        }
        maximum
    };

    let mut entries = vec![0; entry_count];
    for left_mask in 1..subset_count {
        let left_index = left_mask - 1;
        for right_mask in (left_mask + 1)..subset_count {
            let right_index = right_mask - 1;
            let value = directed(left_mask, right_mask).max(directed(right_mask, left_mask));
            entries[left_index * point_count + right_index] = value;
            entries[right_index * point_count + left_index] = value;
        }
    }
    Ok(Metric {
        order: point_count,
        entries,
    })
}

#[derive(Clone, Copy, Default, Debug)]
struct DilationStats {
    distance_queries: u64,
    distance_cache_hits: u64,
    dilation_tests: u64,
}

struct HausdorffOracle<'a> {
    base: &'a Metric,
    levels: Vec<u32>,
    balls: Vec<Vec<u64>>,
    distance_cache: HashMap<u64, u32>,
    max_cache_entries: usize,
    stats: DilationStats,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum LazyStrategy {
    Auto,
    Generic,
    Ultrametric,
    Z3,
}

#[derive(Clone, Debug)]
struct LazyConfig {
    max_depth: usize,
    max_search_nodes: u64,
    max_candidate_scans: u64,
    max_distance_cache: usize,
    mrv_window: usize,
    max_ultrametric_blocks: usize,
    max_ultrametric_assignments: u64,
    max_z3_variables: usize,
    max_z3_clauses: u64,
    z3_timeout_seconds: u64,
}

impl Default for LazyConfig {
    fn default() -> Self {
        Self {
            max_depth: DEFAULT_MAX_LAZY_DEPTH,
            max_search_nodes: DEFAULT_MAX_SEARCH_NODES,
            max_candidate_scans: DEFAULT_MAX_CANDIDATE_SCANS,
            max_distance_cache: DEFAULT_MAX_DISTANCE_CACHE,
            mrv_window: DEFAULT_MRV_WINDOW,
            max_ultrametric_blocks: DEFAULT_MAX_ULTRAMETRIC_BLOCKS,
            max_ultrametric_assignments: DEFAULT_MAX_ULTRAMETRIC_ASSIGNMENTS,
            max_z3_variables: DEFAULT_MAX_Z3_VARIABLES,
            max_z3_clauses: DEFAULT_MAX_Z3_CLAUSES,
            z3_timeout_seconds: DEFAULT_Z3_TIMEOUT_SECONDS,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
struct RelationPair {
    left: u64,
    right: u64,
}

#[derive(Clone, Copy, Debug)]
enum UncoveredPoint {
    Left(u64),
    Right(u64),
}

#[derive(Default, Debug)]
struct LazyFeasibilityStats {
    search_nodes: u64,
    candidate_scans: u64,
    compatibility_checks: u64,
    maximum_depth: usize,
    memo_hits: u64,
}

fn hyperspace_point_order(eccentricities: &[u32]) -> Vec<u64> {
    let mut frequencies = HashMap::new();
    for value in eccentricities.iter().skip(1) {
        *frequencies.entry(*value).or_insert(0_usize) += 1;
    }
    let mut points: Vec<u64> = (1..eccentricities.len() as u64).collect();
    points.sort_unstable_by_key(|mask| {
        let eccentricity = eccentricities[*mask as usize];
        (
            frequencies[&eccentricity],
            u32::MAX - eccentricity,
            mask.count_ones(),
            *mask,
        )
    });
    points
}

struct LazyCorrespondenceSolver<'oracle, 'metric> {
    left: &'oracle mut HausdorffOracle<'metric>,
    right: &'oracle mut HausdorffOracle<'metric>,
    epsilon: u32,
    config: &'oracle LazyConfig,
    left_eccentricities: &'oracle [u32],
    right_eccentricities: &'oracle [u32],
    left_order: &'oracle [u64],
    right_order: &'oracle [u64],
    covered_left: BitSet,
    covered_right: BitSet,
    covered_left_count: usize,
    covered_right_count: usize,
    left_degrees: Vec<u32>,
    right_degrees: Vec<u32>,
    selected: Vec<RelationPair>,
    failed: HashSet<Vec<RelationPair>>,
    stats: LazyFeasibilityStats,
}

impl<'oracle, 'metric> LazyCorrespondenceSolver<'oracle, 'metric> {
    #[allow(clippy::too_many_arguments)]
    fn new(
        left: &'oracle mut HausdorffOracle<'metric>,
        right: &'oracle mut HausdorffOracle<'metric>,
        epsilon: u32,
        config: &'oracle LazyConfig,
        left_eccentricities: &'oracle [u32],
        right_eccentricities: &'oracle [u32],
        left_order: &'oracle [u64],
        right_order: &'oracle [u64],
    ) -> Result<Self, String> {
        let left_count = left.point_count();
        let right_count = right.point_count();
        if left_count.max(right_count) > config.max_depth {
            return Err(format!(
                "generic lazy search needs at least {} covering edges, above the depth \
                 limit {} (use ultrametric decomposition or raise --max-lazy-depth)",
                left_count.max(right_count),
                config.max_depth
            ));
        }
        Ok(Self {
            left,
            right,
            epsilon,
            config,
            left_eccentricities,
            right_eccentricities,
            left_order,
            right_order,
            covered_left: BitSet::empty(left_count),
            covered_right: BitSet::empty(right_count),
            covered_left_count: 0,
            covered_right_count: 0,
            left_degrees: vec![0; left_count],
            right_degrees: vec![0; right_count],
            selected: Vec::with_capacity(left_count.max(right_count)),
            failed: HashSet::new(),
            stats: LazyFeasibilityStats::default(),
        })
    }

    fn solve(mut self) -> Result<(bool, LazyFeasibilityStats), String> {
        if self.epsilon < self.right.base.minimum_positive_distance()
            && self.left.point_count() < self.right.point_count()
        {
            return Ok((false, self.stats));
        }
        if self.epsilon < self.left.base.minimum_positive_distance()
            && self.right.point_count() < self.left.point_count()
        {
            return Ok((false, self.stats));
        }
        let result = self.search()?;
        Ok((result, self.stats))
    }

    fn compatible_with_selected(&mut self, candidate: RelationPair) -> bool {
        for index in 0..self.selected.len() {
            let selected = self.selected[index];
            self.stats.compatibility_checks += 1;
            let left_distance = self.left.distance(candidate.left, selected.left);
            let right_distance = self.right.distance(candidate.right, selected.right);
            if left_distance.abs_diff(right_distance) > self.epsilon {
                return false;
            }
        }
        true
    }

    fn point_pair_admissible(&self, left: u64, right: u64) -> bool {
        let left_index = left as usize - 1;
        let right_index = right as usize - 1;
        let left_functional = self.epsilon < self.right.base.minimum_positive_distance();
        let right_functional = self.epsilon < self.left.base.minimum_positive_distance();
        let bijection_forced = self.left.point_count() == self.right.point_count()
            && (left_functional || right_functional);
        if (left_functional || bijection_forced) && self.left_degrees[left_index] > 0 {
            return false;
        }
        if (right_functional || bijection_forced) && self.right_degrees[right_index] > 0 {
            return false;
        }
        self.left_eccentricities[left as usize].abs_diff(self.right_eccentricities[right as usize])
            <= self.epsilon
    }

    fn preserves_star_forest(&self, candidate: RelationPair) -> bool {
        // Every feasible correspondence contains an inclusion-minimal feasible
        // subcorrespondence.  In such a bipartite graph each edge has a leaf
        // endpoint, so every connected component is a star.  Restricting the
        // search to star forests therefore preserves exact feasibility.
        let candidate_left = candidate.left as usize - 1;
        let candidate_right = candidate.right as usize - 1;
        let candidate_left_degree = self.left_degrees[candidate_left] + 1;
        let candidate_right_degree = self.right_degrees[candidate_right] + 1;
        if candidate_left_degree > 1 && candidate_right_degree > 1 {
            return false;
        }
        for pair in &self.selected {
            let left_index = pair.left as usize - 1;
            let right_index = pair.right as usize - 1;
            let left_degree =
                self.left_degrees[left_index] + u32::from(left_index == candidate_left);
            let right_degree =
                self.right_degrees[right_index] + u32::from(right_index == candidate_right);
            if left_degree > 1 && right_degree > 1 {
                return false;
            }
        }
        true
    }

    fn candidate_options(
        &mut self,
        point: UncoveredPoint,
        cutoff: Option<usize>,
    ) -> Result<(Vec<RelationPair>, bool), String> {
        let mut options = Vec::new();
        match point {
            UncoveredPoint::Left(left) => {
                for right in 1..=self.right.point_count() as u64 {
                    self.stats.candidate_scans += 1;
                    if self.stats.candidate_scans > self.config.max_candidate_scans {
                        return Err(format!(
                            "lazy candidate-scan limit {} reached at node {} and depth {}",
                            self.config.max_candidate_scans,
                            self.stats.search_nodes,
                            self.selected.len(),
                        ));
                    }
                    let pair = RelationPair { left, right };
                    if self.point_pair_admissible(left, right)
                        && self.preserves_star_forest(pair)
                        && self.compatible_with_selected(pair)
                    {
                        options.push(pair);
                        if cutoff.is_some_and(|limit| options.len() > limit) {
                            return Ok((Vec::new(), true));
                        }
                    }
                }
                options.sort_unstable_by_key(|pair| {
                    (
                        usize::from(self.covered_right.contains(pair.right as usize - 1)),
                        usize::from(pair.left != pair.right),
                        pair.left.abs_diff(pair.right),
                        pair.right,
                    )
                });
            }
            UncoveredPoint::Right(right) => {
                for left in 1..=self.left.point_count() as u64 {
                    self.stats.candidate_scans += 1;
                    if self.stats.candidate_scans > self.config.max_candidate_scans {
                        return Err(format!(
                            "lazy candidate-scan limit {} reached at node {} and depth {}",
                            self.config.max_candidate_scans,
                            self.stats.search_nodes,
                            self.selected.len(),
                        ));
                    }
                    let pair = RelationPair { left, right };
                    if self.point_pair_admissible(left, right)
                        && self.preserves_star_forest(pair)
                        && self.compatible_with_selected(pair)
                    {
                        options.push(pair);
                        if cutoff.is_some_and(|limit| options.len() > limit) {
                            return Ok((Vec::new(), true));
                        }
                    }
                }
                options.sort_unstable_by_key(|pair| {
                    (
                        usize::from(self.covered_left.contains(pair.left as usize - 1)),
                        usize::from(pair.left != pair.right),
                        pair.left.abs_diff(pair.right),
                        pair.left,
                    )
                });
            }
        }
        Ok((options, false))
    }

    fn frontier(&self) -> Vec<UncoveredPoint> {
        let window = self.config.mrv_window.max(1);
        let mut result = Vec::with_capacity(2 * window);
        for point in self.left_order {
            if !self.covered_left.contains(*point as usize - 1) {
                result.push(UncoveredPoint::Left(*point));
                if result.len() == window {
                    break;
                }
            }
        }
        let left_entries = result.len();
        for point in self.right_order {
            if !self.covered_right.contains(*point as usize - 1) {
                result.push(UncoveredPoint::Right(*point));
                if result.len() == left_entries + window {
                    break;
                }
            }
        }
        result
    }

    fn best_options(&mut self) -> Result<Vec<RelationPair>, String> {
        let mut best: Option<Vec<RelationPair>> = None;
        for point in self.frontier() {
            let cutoff = best.as_ref().map(Vec::len);
            let (options, truncated) = self.candidate_options(point, cutoff)?;
            if truncated {
                continue;
            }
            if options.is_empty() {
                return Ok(options);
            }
            if best
                .as_ref()
                .is_none_or(|current| options.len() < current.len())
            {
                best = Some(options);
            }
        }
        best.ok_or_else(|| "no uncovered hyperspace point was found".to_string())
    }

    fn search(&mut self) -> Result<bool, String> {
        self.stats.search_nodes += 1;
        if self.stats.search_nodes > self.config.max_search_nodes {
            return Err(format!(
                "lazy search-node limit {} reached",
                self.config.max_search_nodes
            ));
        }
        self.stats.maximum_depth = self.stats.maximum_depth.max(self.selected.len());
        if self.covered_left_count == self.left.point_count()
            && self.covered_right_count == self.right.point_count()
        {
            return Ok(true);
        }
        if self.selected.len() >= self.config.max_depth {
            return Err(format!(
                "lazy correspondence depth limit {} reached",
                self.config.max_depth
            ));
        }
        let mut memo_key = self.selected.clone();
        memo_key.sort_unstable();
        if self.failed.contains(&memo_key) {
            self.stats.memo_hits += 1;
            return Ok(false);
        }

        let options = self.best_options()?;
        for pair in options {
            let left_index = pair.left as usize - 1;
            let right_index = pair.right as usize - 1;
            let new_left = !self.covered_left.contains(left_index);
            let new_right = !self.covered_right.contains(right_index);
            debug_assert!(new_left || new_right);
            if new_left {
                self.covered_left.set(left_index);
                self.covered_left_count += 1;
            }
            if new_right {
                self.covered_right.set(right_index);
                self.covered_right_count += 1;
            }
            self.left_degrees[left_index] += 1;
            self.right_degrees[right_index] += 1;
            self.selected.push(pair);
            if self.search()? {
                return Ok(true);
            }
            self.left_degrees[left_index] -= 1;
            self.right_degrees[right_index] -= 1;
            self.selected.pop();
            if new_left {
                self.covered_left.clear(left_index);
                self.covered_left_count -= 1;
            }
            if new_right {
                self.covered_right.clear(right_index);
                self.covered_right_count -= 1;
            }
        }
        if self.failed.len() < 250_000 {
            self.failed.insert(memo_key);
        }
        Ok(false)
    }
}

impl<'a> HausdorffOracle<'a> {
    fn new(base: &'a Metric, max_cache_entries: usize) -> Result<Self, String> {
        if base.order > 20 {
            return Err(format!(
                "lazy hyperspace masks support base order at most 20, received {}",
                base.order
            ));
        }
        let levels: Vec<u32> = base.distance_levels().into_iter().collect();
        let mut balls = Vec::with_capacity(levels.len());
        for level in &levels {
            let mut point_balls = vec![0_u64; base.order];
            for (center, ball) in point_balls.iter_mut().enumerate() {
                for point in 0..base.order {
                    if base.get(center, point) <= *level {
                        *ball |= 1_u64 << point;
                    }
                }
            }
            balls.push(point_balls);
        }
        Ok(Self {
            base,
            levels,
            balls,
            distance_cache: HashMap::new(),
            max_cache_entries,
            stats: DilationStats::default(),
        })
    }

    fn point_count(&self) -> usize {
        (1_usize << self.base.order) - 1
    }

    fn pair_key(&self, left: u64, right: u64) -> u64 {
        let (small, large) = if left <= right {
            (left, right)
        } else {
            (right, left)
        };
        (small << self.base.order) | large
    }

    fn dilation(&mut self, subset: u64, level_index: usize) -> u64 {
        let mut remaining = subset;
        let mut result = 0_u64;
        while remaining != 0 {
            let point = remaining.trailing_zeros() as usize;
            result |= self.balls[level_index][point];
            remaining &= remaining - 1;
        }
        result
    }

    fn distance_leq_at_level(&mut self, left: u64, right: u64, level_index: usize) -> bool {
        self.stats.dilation_tests += 1;
        let right_dilation = self.dilation(right, level_index);
        if left & !right_dilation != 0 {
            return false;
        }
        let left_dilation = self.dilation(left, level_index);
        right & !left_dilation == 0
    }

    fn distance(&mut self, left: u64, right: u64) -> u32 {
        self.stats.distance_queries += 1;
        if left == right {
            return 0;
        }
        let key = self.pair_key(left, right);
        if let Some(value) = self.distance_cache.get(&key) {
            self.stats.distance_cache_hits += 1;
            return *value;
        }
        let mut lower = 0;
        let mut upper = self.levels.len() - 1;
        while lower < upper {
            let middle = lower + (upper - lower) / 2;
            if self.distance_leq_at_level(left, right, middle) {
                upper = middle;
            } else {
                lower = middle + 1;
            }
        }
        let result = self.levels[lower];
        if self.distance_cache.len() < self.max_cache_entries {
            self.distance_cache.insert(key, result);
        }
        result
    }

    fn subset_eccentricities(&self) -> Vec<u32> {
        let subset_count = 1_usize << self.base.order;
        let point_eccentricities: Vec<u32> = (0..self.base.order)
            .map(|point| {
                (0..self.base.order)
                    .map(|other| self.base.get(point, other))
                    .max()
                    .unwrap_or(0)
            })
            .collect();
        let mut result = vec![0; subset_count];
        for mask in 1..subset_count {
            let point = mask.trailing_zeros() as usize;
            let remainder = mask & (mask - 1);
            result[mask] = result[remainder].max(point_eccentricities[point]);
        }
        result
    }

    fn partition_by_open_support(&self, points: &[u64], threshold: u32) -> Vec<Vec<u64>> {
        let labels = self.base.open_component_labels(threshold);
        let mut groups: BTreeMap<u64, Vec<u64>> = BTreeMap::new();
        for subset in points {
            let mut remaining = *subset;
            let mut support = 0_u64;
            while remaining != 0 {
                let point = remaining.trailing_zeros() as usize;
                support |= 1_u64 << labels[point];
                remaining &= remaining - 1;
            }
            groups.entry(support).or_default().push(*subset);
        }
        groups.into_values().collect()
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct UltrametricMemoKey {
    orientation_swapped: bool,
    epsilon: u32,
    left_points: Vec<u64>,
    right_points: Vec<u64>,
}

#[derive(Default, Debug)]
struct UltrametricStats {
    recursive_calls: u64,
    memo_hits: u64,
    partitions_built: u64,
    assignment_candidates: u64,
    maximum_block_count: usize,
}

struct UltrametricRecursor<'config> {
    config: &'config LazyConfig,
    memo: HashMap<UltrametricMemoKey, bool>,
    stats: UltrametricStats,
}

impl<'config> UltrametricRecursor<'config> {
    fn new(config: &'config LazyConfig) -> Self {
        Self {
            config,
            memo: HashMap::new(),
            stats: UltrametricStats::default(),
        }
    }

    fn subspace_diameter(points: &[u64], oracle: &mut HausdorffOracle<'_>) -> u32 {
        let first = points[0];
        points
            .iter()
            .map(|point| oracle.distance(first, *point))
            .max()
            .unwrap_or(0)
    }

    fn union_blocks(blocks: &[Vec<u64>], mask: u64) -> Vec<u64> {
        let mut points = Vec::new();
        for (index, block) in blocks.iter().enumerate() {
            if mask & (1_u64 << index) != 0 {
                points.extend(block);
            }
        }
        points.sort_unstable();
        points
    }

    fn decide(
        &mut self,
        left_points: &[u64],
        right_points: &[u64],
        left_oracle: &mut HausdorffOracle<'_>,
        right_oracle: &mut HausdorffOracle<'_>,
        epsilon: u32,
        orientation_swapped: bool,
    ) -> Result<bool, String> {
        self.stats.recursive_calls += 1;
        if self.stats.recursive_calls > self.config.max_search_nodes {
            return Err(format!(
                "ultrametric recursion-call limit {} reached",
                self.config.max_search_nodes
            ));
        }
        let memoizable = left_points.len() + right_points.len() <= 4_096;
        let key = memoizable.then(|| UltrametricMemoKey {
            orientation_swapped,
            epsilon,
            left_points: left_points.to_vec(),
            right_points: right_points.to_vec(),
        });
        if let Some(cached) = key.as_ref().and_then(|value| self.memo.get(value)) {
            self.stats.memo_hits += 1;
            return Ok(*cached);
        }

        let left_diameter = Self::subspace_diameter(left_points, left_oracle);
        let right_diameter = Self::subspace_diameter(right_points, right_oracle);
        let result = if left_diameter.abs_diff(right_diameter) > epsilon {
            false
        } else if left_diameter.max(right_diameter) <= epsilon {
            true
        } else if right_diameter <= epsilon {
            self.decide(
                right_points,
                left_points,
                right_oracle,
                left_oracle,
                epsilon,
                !orientation_swapped,
            )?
        } else {
            let left_threshold = right_diameter - epsilon;
            // Distinct top blocks on the right are exactly right_diameter
            // apart.  An epsilon-correspondence cannot send one open
            // (< right_diameter - epsilon) block on the left to two of them.
            // For ultrametrics the converse gluing is exact because all
            // inter-block distances are constant at the relevant level.
            let left_blocks = left_oracle.partition_by_open_support(left_points, left_threshold);
            let mut right_blocks =
                right_oracle.partition_by_open_support(right_points, right_diameter);
            self.stats.partitions_built += 2;
            self.stats.maximum_block_count = self
                .stats
                .maximum_block_count
                .max(left_blocks.len())
                .max(right_blocks.len());

            if left_blocks.len() < right_blocks.len() {
                false
            } else {
                if left_blocks.len() > self.config.max_ultrametric_blocks || left_blocks.len() >= 64
                {
                    return Err(format!(
                        "ultrametric decomposition produced {} source blocks, above the \
                         limit {}",
                        left_blocks.len(),
                        self.config.max_ultrametric_blocks
                    ));
                }
                right_blocks.sort_unstable_by_key(|block| usize::MAX - block.len());
                let full = (1_u64 << left_blocks.len()) - 1;
                let mut local_cache = vec![HashMap::new(); right_blocks.len()];
                self.assign_blocks(
                    0,
                    full,
                    &left_blocks,
                    &right_blocks,
                    left_oracle,
                    right_oracle,
                    epsilon,
                    orientation_swapped,
                    &mut local_cache,
                )?
            }
        };
        if let Some(key) = key {
            self.memo.insert(key, result);
        }
        Ok(result)
    }

    #[allow(clippy::too_many_arguments)]
    fn assign_blocks(
        &mut self,
        target_index: usize,
        remaining: u64,
        left_blocks: &[Vec<u64>],
        right_blocks: &[Vec<u64>],
        left_oracle: &mut HausdorffOracle<'_>,
        right_oracle: &mut HausdorffOracle<'_>,
        epsilon: u32,
        orientation_swapped: bool,
        local_cache: &mut [HashMap<u64, bool>],
    ) -> Result<bool, String> {
        if target_index == right_blocks.len() {
            return Ok(remaining == 0);
        }
        let targets_left = right_blocks.len() - target_index;
        if (remaining.count_ones() as usize) < targets_left {
            return Ok(false);
        }

        let mut subset = remaining;
        while subset != 0 {
            self.stats.assignment_candidates += 1;
            if self.stats.assignment_candidates > self.config.max_ultrametric_assignments {
                return Err(format!(
                    "ultrametric block-assignment limit {} reached",
                    self.config.max_ultrametric_assignments
                ));
            }
            let leftover = remaining ^ subset;
            if leftover.count_ones() as usize + 1 >= targets_left {
                let feasible = if let Some(value) = local_cache[target_index].get(&subset) {
                    *value
                } else {
                    let source_points = Self::union_blocks(left_blocks, subset);
                    let value = self.decide(
                        &source_points,
                        &right_blocks[target_index],
                        left_oracle,
                        right_oracle,
                        epsilon,
                        orientation_swapped,
                    )?;
                    local_cache[target_index].insert(subset, value);
                    value
                };
                if feasible
                    && self.assign_blocks(
                        target_index + 1,
                        leftover,
                        left_blocks,
                        right_blocks,
                        left_oracle,
                        right_oracle,
                        epsilon,
                        orientation_swapped,
                        local_cache,
                    )?
                {
                    return Ok(true);
                }
            }
            subset = (subset - 1) & remaining;
        }
        Ok(false)
    }
}

#[derive(Default, Debug)]
struct LazyExactStats {
    candidate_thresholds: usize,
    feasibility_checks: u64,
    generic_checks: u64,
    ultrametric_checks: u64,
    ultrametric_fallbacks: u64,
    z3_checks: u64,
    z3_fallbacks: u64,
    z3_variables: usize,
    z3_clauses: u64,
    lazy_search_nodes: u64,
    candidate_scans: u64,
    compatibility_checks: u64,
    lazy_memo_hits: u64,
    maximum_depth: usize,
    ultrametric_recursive_calls: u64,
    ultrametric_assignment_candidates: u64,
    ultrametric_maximum_block_count: usize,
    left_dilation: DilationStats,
    right_dilation: DilationStats,
    structural: StructuralStats,
}

struct LazyHyperspaceEngine<'metric, 'config> {
    left_base: &'metric Metric,
    right_base: &'metric Metric,
    left: HausdorffOracle<'metric>,
    right: HausdorffOracle<'metric>,
    config: &'config LazyConfig,
    strategy: LazyStrategy,
    left_eccentricities: Vec<u32>,
    right_eccentricities: Vec<u32>,
    left_point_order: Option<Vec<u64>>,
    right_point_order: Option<Vec<u64>>,
    structural: StructuralFilter<'metric>,
    stats: LazyExactStats,
}

impl<'metric, 'config> LazyHyperspaceEngine<'metric, 'config> {
    fn new(
        left_base: &'metric Metric,
        right_base: &'metric Metric,
        config: &'config LazyConfig,
        strategy: LazyStrategy,
    ) -> Result<Self, String> {
        if strategy == LazyStrategy::Ultrametric
            && (!left_base.is_ultrametric() || !right_base.is_ultrametric())
        {
            return Err("the ultrametric strategy requires two ultrametric bases".to_string());
        }
        let left = HausdorffOracle::new(left_base, config.max_distance_cache)?;
        let right = HausdorffOracle::new(right_base, config.max_distance_cache)?;
        let left_eccentricities = left.subset_eccentricities();
        let right_eccentricities = right.subset_eccentricities();
        Ok(Self {
            left_base,
            right_base,
            left,
            right,
            config,
            strategy,
            left_eccentricities,
            right_eccentricities,
            left_point_order: None,
            right_point_order: None,
            structural: StructuralFilter::new(left_base, right_base),
            stats: LazyExactStats::default(),
        })
    }

    fn equilateral_feasible(&self, epsilon: u32) -> Option<bool> {
        let left_distance = self.left_base.is_equilateral()?;
        let right_distance = self.right_base.is_equilateral()?;
        let left_count = self.left.point_count();
        let right_count = self.right.point_count();
        Some(
            left_distance.abs_diff(right_distance) <= epsilon
                && (left_distance <= epsilon || left_count <= right_count)
                && (right_distance <= epsilon || right_count <= left_count),
        )
    }

    fn generic_feasible(&mut self, epsilon: u32) -> Result<bool, String> {
        if self.left_point_order.is_none() {
            self.left_point_order = Some(hyperspace_point_order(&self.left_eccentricities));
        }
        if self.right_point_order.is_none() {
            self.right_point_order = Some(hyperspace_point_order(&self.right_eccentricities));
        }
        let solver = LazyCorrespondenceSolver::new(
            &mut self.left,
            &mut self.right,
            epsilon,
            self.config,
            &self.left_eccentricities,
            &self.right_eccentricities,
            self.left_point_order.as_ref().unwrap(),
            self.right_point_order.as_ref().unwrap(),
        )?;
        let (result, run) = solver.solve()?;
        self.stats.generic_checks += 1;
        self.stats.lazy_search_nodes += run.search_nodes;
        self.stats.candidate_scans += run.candidate_scans;
        self.stats.compatibility_checks += run.compatibility_checks;
        self.stats.lazy_memo_hits += run.memo_hits;
        self.stats.maximum_depth = self.stats.maximum_depth.max(run.maximum_depth);
        Ok(result)
    }

    fn ultrametric_feasible(&mut self, epsilon: u32) -> Result<bool, String> {
        let left_points: Vec<u64> = (1..=self.left.point_count() as u64).collect();
        let right_points: Vec<u64> = (1..=self.right.point_count() as u64).collect();
        let mut recursor = UltrametricRecursor::new(self.config);
        let result = recursor.decide(
            &left_points,
            &right_points,
            &mut self.left,
            &mut self.right,
            epsilon,
            false,
        );
        self.stats.ultrametric_checks += 1;
        self.stats.ultrametric_recursive_calls += recursor.stats.recursive_calls;
        self.stats.ultrametric_assignment_candidates += recursor.stats.assignment_candidates;
        self.stats.ultrametric_maximum_block_count = self
            .stats
            .ultrametric_maximum_block_count
            .max(recursor.stats.maximum_block_count);
        result
    }

    fn z3_feasible(&mut self, epsilon: u32) -> Result<bool, String> {
        let left_count = self.left.point_count();
        let right_count = self.right.point_count();
        let mut variables = Vec::new();
        let mut row_variables = vec![Vec::new(); left_count];
        let mut column_variables = vec![Vec::new(); right_count];
        for left in 1..=left_count as u64 {
            for right in 1..=right_count as u64 {
                if self.left_eccentricities[left as usize]
                    .abs_diff(self.right_eccentricities[right as usize])
                    > epsilon
                {
                    continue;
                }
                let variable = variables.len() + 1;
                variables.push(RelationPair { left, right });
                row_variables[left as usize - 1].push(variable);
                column_variables[right as usize - 1].push(variable);
            }
        }
        if row_variables.iter().any(Vec::is_empty) || column_variables.iter().any(Vec::is_empty) {
            return Ok(false);
        }
        if variables.len() > self.config.max_z3_variables {
            return Err(format!(
                "Z3 encoding needs {} variables, above the limit {}",
                variables.len(),
                self.config.max_z3_variables
            ));
        }

        let mut body = String::new();
        let mut clause_count = 0_u64;
        for clause in row_variables.iter().chain(&column_variables) {
            for variable in clause {
                let _ = write!(&mut body, "{variable} ");
            }
            body.push_str("0\n");
            clause_count += 1;
        }
        for first_index in 0..variables.len() {
            let first = variables[first_index];
            for (second_index, second) in variables.iter().enumerate().skip(first_index + 1) {
                let left_distance = self.left.distance(first.left, second.left);
                let right_distance = self.right.distance(first.right, second.right);
                if left_distance.abs_diff(right_distance) > epsilon {
                    let _ = writeln!(&mut body, "-{} -{} 0", first_index + 1, second_index + 1);
                    clause_count += 1;
                    if clause_count > self.config.max_z3_clauses {
                        return Err(format!(
                            "Z3 encoding exceeded the clause limit {}",
                            self.config.max_z3_clauses
                        ));
                    }
                }
            }
        }

        let mut input = format!("p cnf {} {}\n", variables.len(), clause_count);
        input.push_str(&body);
        let timeout = format!("-T:{}", self.config.z3_timeout_seconds);
        let mut child = Command::new("z3")
            .args(["-dimacs", "-in", &timeout])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|error| format!("failed to start optional Z3 backend: {error}"))?;
        child
            .stdin
            .as_mut()
            .ok_or_else(|| "Z3 stdin was not available".to_string())?
            .write_all(input.as_bytes())
            .map_err(|error| format!("failed to write Z3 DIMACS input: {error}"))?;
        drop(child.stdin.take());
        let output = child
            .wait_with_output()
            .map_err(|error| format!("failed while waiting for Z3: {error}"))?;
        self.stats.z3_checks += 1;
        self.stats.z3_variables = self.stats.z3_variables.max(variables.len());
        self.stats.z3_clauses = self.stats.z3_clauses.max(clause_count);
        let stdout = String::from_utf8_lossy(&output.stdout).to_lowercase();
        if stdout.contains("unsat") {
            Ok(false)
        } else if stdout.contains("sat") {
            Ok(true)
        } else {
            let stderr = String::from_utf8_lossy(&output.stderr);
            Err(format!(
                "Z3 returned neither sat nor unsat (status={}): {}{}",
                output.status,
                stdout.trim(),
                stderr.trim()
            ))
        }
    }

    fn feasible(&mut self, epsilon: u32) -> Result<bool, String> {
        self.stats.feasibility_checks += 1;
        if !self.structural.accepts(epsilon) {
            return Ok(false);
        }
        if let Some(result) = self.equilateral_feasible(epsilon) {
            return Ok(result);
        }
        if self.strategy == LazyStrategy::Z3 {
            return self.z3_feasible(epsilon);
        }
        let use_ultrametric = self.strategy != LazyStrategy::Generic
            && self.left_base.is_ultrametric()
            && self.right_base.is_ultrametric();
        if use_ultrametric {
            match self.ultrametric_feasible(epsilon) {
                Ok(result) => return Ok(result),
                Err(ultrametric_limit) if self.strategy == LazyStrategy::Auto => {
                    self.stats.ultrametric_fallbacks += 1;
                    return self.generic_feasible(epsilon).map_err(|generic_limit| {
                        format!(
                            "ultrametric decomposition stopped ({ultrametric_limit}); \
                             generic fallback stopped ({generic_limit})"
                        )
                    });
                }
                Err(error) => return Err(error),
            }
        }
        let implicit_relation_vertices = self.left.point_count() * self.right.point_count();
        // Tiny instances are faster in the in-process star-forest solver;
        // medium instances benefit from a bounded exact SAT encoding.
        if self.strategy == LazyStrategy::Auto
            && (AUTO_Z3_MIN_RELATION_VERTICES..=AUTO_Z3_RELATION_VERTICES)
                .contains(&implicit_relation_vertices)
        {
            match self.z3_feasible(epsilon) {
                Ok(result) => return Ok(result),
                Err(_) => self.stats.z3_fallbacks += 1,
            }
        }
        self.generic_feasible(epsilon)
    }

    fn finish(mut self) -> LazyExactStats {
        self.stats.left_dilation = self.left.stats;
        self.stats.right_dilation = self.right.stats;
        self.stats.structural = self.structural.stats;
        self.stats
    }
}

fn minimum_hyperspace_distortion_lazy(
    left: &Metric,
    right: &Metric,
    config: &LazyConfig,
    strategy: LazyStrategy,
    certified_upper_bound: Option<u32>,
) -> Result<(u32, LazyExactStats), String> {
    let thresholds = candidate_thresholds(left, right);
    let upper_bound =
        certified_upper_bound.unwrap_or_else(|| labelled_correspondence_upper_bound(left, right));
    let lower_bound = structural_lower_bound(left, right);
    let lower_index = thresholds.partition_point(|value| *value < lower_bound);
    let upper_index = thresholds
        .binary_search(&upper_bound)
        .map_err(|_| "the explicit correspondence upper bound is not a candidate threshold")?;
    if lower_index > upper_index {
        return Err(format!(
            "structural lower bound {lower_bound} exceeds correspondence upper bound \
             {upper_bound}"
        ));
    }

    let mut engine = LazyHyperspaceEngine::new(left, right, config, strategy)?;
    engine.stats.candidate_thresholds = thresholds.len();
    if left == right {
        return Ok((0, engine.finish()));
    }
    if !engine.structural.accepts(upper_bound) {
        return Err("structural filter rejected a certified lifted upper bound".to_string());
    }

    let mut lower = lower_index;
    let mut upper = upper_index;
    while lower < upper {
        let middle = lower + (upper - lower) / 2;
        if engine.feasible(thresholds[middle])? {
            upper = middle;
        } else {
            lower = middle + 1;
        }
    }
    Ok((thresholds[lower], engine.finish()))
}

fn brute_force_minimum_distortion(left: &Metric, right: &Metric) -> Result<u32, String> {
    let vertex_count = left.order * right.order;
    if vertex_count > 20 {
        return Err("brute-force check is limited to 20 relation vertices".to_string());
    }
    let mut best = u32::MAX;
    for relation in 1_u64..(1_u64 << vertex_count) {
        let mut rows = 0_u64;
        let mut columns = 0_u64;
        for vertex in 0..vertex_count {
            if relation & (1_u64 << vertex) != 0 {
                rows |= 1_u64 << (vertex / right.order);
                columns |= 1_u64 << (vertex % right.order);
            }
        }
        if rows.count_ones() as usize != left.order || columns.count_ones() as usize != right.order
        {
            continue;
        }
        let mut distortion = 0;
        for first in 0..vertex_count {
            if relation & (1_u64 << first) == 0 {
                continue;
            }
            let i = first / right.order;
            let j = first % right.order;
            for second in 0..vertex_count {
                if relation & (1_u64 << second) == 0 {
                    continue;
                }
                let k = second / right.order;
                let ell = second % right.order;
                distortion = distortion.max(left.get(i, k).abs_diff(right.get(j, ell)));
            }
        }
        best = best.min(distortion);
    }
    Ok(best)
}

fn parse_edges(text: &str) -> Result<Vec<u32>, String> {
    text.split(',')
        .map(|part| {
            part.trim()
                .parse::<u32>()
                .map_err(|error| format!("invalid edge length {part:?}: {error}"))
        })
        .collect()
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum EngineMode {
    Auto,
    Explicit,
    Lazy,
    LazyGeneric,
    Ultrametric,
    Z3,
}

fn parse_engine(value: &str) -> Result<EngineMode, String> {
    match value {
        "auto" => Ok(EngineMode::Auto),
        "explicit" => Ok(EngineMode::Explicit),
        "lazy" => Ok(EngineMode::Lazy),
        "lazy-generic" => Ok(EngineMode::LazyGeneric),
        "ultrametric" => Ok(EngineMode::Ultrametric),
        "z3" => Ok(EngineMode::Z3),
        _ => Err(format!(
            "unknown engine {value:?}; choose auto, explicit, lazy, \
             lazy-generic, ultrametric, or z3"
        )),
    }
}

#[derive(Debug)]
struct Arguments {
    self_test: bool,
    known_pair: bool,
    hyperspace: bool,
    compare_base: bool,
    left_edges: Option<Vec<u32>>,
    right_edges: Option<Vec<u32>>,
    left_family: Option<String>,
    right_family: Option<String>,
    order: Option<usize>,
    engine: EngineMode,
    max_hyperspace_points: usize,
    max_relation_vertices: usize,
    lazy_config: LazyConfig,
}

fn usage() -> &'static str {
    "Usage:\n\
  cargo run --release -- --self-test\n\
  cargo run --release -- --known-pair [--hyperspace]\n\
  cargo run --release -- --left-edges a,b,c --right-edges d,e,f [--hyperspace]\n\
  cargo run --release -- --left-family NAME --right-family NAME --order N\n\
Options:\n\
  --engine MODE               auto, explicit, lazy, lazy-generic, ultrametric, z3\n\
  --compare-base              use the exact base optimum as a lifted upper bound\n\
  --max-hyperspace-points N   explicit Exp safety limit (default 127)\n\
  --max-relation-vertices N   compatibility-search safety limit (default 20000)\n\
  --max-lazy-depth N          generic implicit-cover depth limit (default 4095)\n\
  --max-search-nodes N        generic/ultrametric recursion limit (default 2000000)\n\
  --max-candidate-scans N     implicit relation-pair scan limit (default 100000000)\n\
  --max-distance-cache N      cached lazy Hausdorff distances (default 4000000)\n\
  --mrv-window N              uncovered rows/columns inspected per side (default 8)\n\
  --max-ultrametric-blocks N  block-assignment width limit (default 24)\n\
  --max-ultrametric-assignments N  recursive block assignments (default 5000000)\n\
  --max-z3-variables N        optional Z3 variable limit (default 5000)\n\
  --max-z3-clauses N          optional Z3 clause limit (default 10000000)\n\
  --z3-timeout-seconds N      optional Z3 timeout (default 30)\n"
}

fn parse_arguments() -> Result<Arguments, String> {
    let mut result = Arguments {
        self_test: false,
        known_pair: false,
        hyperspace: false,
        compare_base: false,
        left_edges: None,
        right_edges: None,
        left_family: None,
        right_family: None,
        order: None,
        engine: EngineMode::Auto,
        max_hyperspace_points: DEFAULT_MAX_HYPERSPACE_POINTS,
        max_relation_vertices: DEFAULT_MAX_RELATION_VERTICES,
        lazy_config: LazyConfig::default(),
    };
    let mut arguments = env::args().skip(1);
    while let Some(argument) = arguments.next() {
        match argument.as_str() {
            "--self-test" => result.self_test = true,
            "--known-pair" => result.known_pair = true,
            "--hyperspace" => result.hyperspace = true,
            "--compare-base" => result.compare_base = true,
            "--left-edges" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--left-edges needs a comma-separated value".to_string())?;
                result.left_edges = Some(parse_edges(&value)?);
            }
            "--right-edges" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--right-edges needs a comma-separated value".to_string())?;
                result.right_edges = Some(parse_edges(&value)?);
            }
            "--left-family" => {
                result.left_family = Some(
                    arguments
                        .next()
                        .ok_or_else(|| "--left-family needs a family name".to_string())?,
                );
            }
            "--right-family" => {
                result.right_family = Some(
                    arguments
                        .next()
                        .ok_or_else(|| "--right-family needs a family name".to_string())?,
                );
            }
            "--order" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--order needs an integer".to_string())?;
                result.order = Some(
                    value
                        .parse()
                        .map_err(|error| format!("invalid order: {error}"))?,
                );
            }
            "--engine" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--engine needs a mode".to_string())?;
                result.engine = parse_engine(&value)?;
            }
            "--max-hyperspace-points" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-hyperspace-points needs an integer".to_string())?;
                result.max_hyperspace_points = value
                    .parse()
                    .map_err(|error| format!("invalid hyperspace limit: {error}"))?;
            }
            "--max-relation-vertices" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-relation-vertices needs an integer".to_string())?;
                result.max_relation_vertices = value
                    .parse()
                    .map_err(|error| format!("invalid relation limit: {error}"))?;
            }
            "--max-lazy-depth" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-lazy-depth needs an integer".to_string())?;
                result.lazy_config.max_depth = value
                    .parse()
                    .map_err(|error| format!("invalid lazy depth: {error}"))?;
            }
            "--max-search-nodes" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-search-nodes needs an integer".to_string())?;
                result.lazy_config.max_search_nodes = value
                    .parse()
                    .map_err(|error| format!("invalid search-node limit: {error}"))?;
            }
            "--max-candidate-scans" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-candidate-scans needs an integer".to_string())?;
                result.lazy_config.max_candidate_scans = value
                    .parse()
                    .map_err(|error| format!("invalid candidate-scan limit: {error}"))?;
            }
            "--max-distance-cache" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-distance-cache needs an integer".to_string())?;
                result.lazy_config.max_distance_cache = value
                    .parse()
                    .map_err(|error| format!("invalid distance-cache limit: {error}"))?;
            }
            "--mrv-window" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--mrv-window needs an integer".to_string())?;
                result.lazy_config.mrv_window = value
                    .parse()
                    .map_err(|error| format!("invalid MRV window: {error}"))?;
            }
            "--max-ultrametric-blocks" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-ultrametric-blocks needs an integer".to_string())?;
                result.lazy_config.max_ultrametric_blocks = value
                    .parse()
                    .map_err(|error| format!("invalid ultrametric block limit: {error}"))?;
            }
            "--max-ultrametric-assignments" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-ultrametric-assignments needs an integer".to_string())?;
                result.lazy_config.max_ultrametric_assignments = value
                    .parse()
                    .map_err(|error| format!("invalid ultrametric assignment limit: {error}"))?;
            }
            "--max-z3-variables" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-z3-variables needs an integer".to_string())?;
                result.lazy_config.max_z3_variables = value
                    .parse()
                    .map_err(|error| format!("invalid Z3 variable limit: {error}"))?;
            }
            "--max-z3-clauses" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--max-z3-clauses needs an integer".to_string())?;
                result.lazy_config.max_z3_clauses = value
                    .parse()
                    .map_err(|error| format!("invalid Z3 clause limit: {error}"))?;
            }
            "--z3-timeout-seconds" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| "--z3-timeout-seconds needs an integer".to_string())?;
                result.lazy_config.z3_timeout_seconds = value
                    .parse()
                    .map_err(|error| format!("invalid Z3 timeout: {error}"))?;
            }
            "--help" | "-h" => {
                print!("{}", usage());
                std::process::exit(0);
            }
            _ => return Err(format!("unknown argument {argument:?}\n{}", usage())),
        }
    }
    if result.left_edges.is_some() != result.right_edges.is_some() {
        return Err("provide both --left-edges and --right-edges".to_string());
    }
    let any_family = result.left_family.is_some() || result.right_family.is_some();
    if any_family
        && (result.left_family.is_none() || result.right_family.is_none() || result.order.is_none())
    {
        return Err("family mode needs --left-family, --right-family, and --order".to_string());
    }
    if result.order.is_some() && !any_family {
        return Err("--order is used only with catalog families".to_string());
    }
    let selected_modes = usize::from(result.known_pair)
        + usize::from(result.left_edges.is_some())
        + usize::from(any_family);
    if selected_modes > 1 {
        return Err("choose only one of known-pair, explicit-edge, and family modes".to_string());
    }
    if !result.hyperspace && !matches!(result.engine, EngineMode::Auto | EngineMode::Explicit) {
        return Err("lazy and ultrametric engines require --hyperspace".to_string());
    }
    if result.compare_base && !result.hyperspace {
        return Err("--compare-base requires --hyperspace".to_string());
    }
    if result.compare_base && result.engine == EngineMode::Explicit {
        return Err("--compare-base is intended for a lazy hyperspace engine".to_string());
    }
    if result.lazy_config.mrv_window == 0 {
        return Err("--mrv-window must be positive".to_string());
    }
    if result.lazy_config.max_ultrametric_blocks == 0 {
        return Err("--max-ultrametric-blocks must be positive".to_string());
    }
    Ok(result)
}

fn run_self_test() -> Result<(), String> {
    let small_cases = [
        (vec![1], vec![3]),
        (vec![2], vec![2, 3, 4]),
        (vec![2, 3, 4], vec![3, 4, 5]),
    ];
    for (index, (left_edges, right_edges)) in small_cases.iter().enumerate() {
        let left = Metric::from_edges(left_edges)?;
        let right = Metric::from_edges(right_edges)?;
        let (exact, _) = minimum_distortion(&left, &right, DEFAULT_MAX_RELATION_VERTICES)?;
        let brute = brute_force_minimum_distortion(&left, &right)?;
        if exact != brute {
            return Err(format!(
                "self-test case {index} differs: exact={exact}, brute={brute}"
            ));
        }
    }

    let left = Metric::from_edges(&KNOWN_LEFT)?;
    let right = Metric::from_edges(&KNOWN_RIGHT)?;
    let (base, _) = minimum_distortion(&left, &right, DEFAULT_MAX_RELATION_VERTICES)?;
    let brute = brute_force_minimum_distortion(&left, &right)?;
    if base != 484 || base != brute {
        return Err(format!(
            "known base pair differs: exact={base}, brute={brute}, expected=484"
        ));
    }
    let exp_left = hyperspace_metric(&left, DEFAULT_MAX_HYPERSPACE_POINTS)?;
    let exp_right = hyperspace_metric(&right, DEFAULT_MAX_HYPERSPACE_POINTS)?;
    let (hyperspace, _) = minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES)?;
    if hyperspace != 484 {
        return Err(format!(
            "known hyperspace pair differs: exact={hyperspace}, expected=484"
        ));
    }
    let config = LazyConfig::default();
    let (lazy_hyperspace, _) =
        minimum_hyperspace_distortion_lazy(&left, &right, &config, LazyStrategy::Generic, None)?;
    if lazy_hyperspace != hyperspace {
        return Err(format!(
            "lazy known-pair result differs: lazy={lazy_hyperspace}, explicit={hyperspace}"
        ));
    }

    let ultrametric_left = Metric::from_edges(&[1, 1, 2, 1, 2, 2])?;
    let ultrametric_right = Metric::from_edges(&[2, 3, 3, 3, 3, 2])?;
    let (ultrametric_hyperspace, _) = minimum_hyperspace_distortion_lazy(
        &ultrametric_left,
        &ultrametric_right,
        &config,
        LazyStrategy::Ultrametric,
        None,
    )?;
    if ultrametric_hyperspace != 2 {
        return Err(format!(
            "ultrametric decomposition differs: exact={ultrametric_hyperspace}, expected=2"
        ));
    }
    println!(
        "SELF_TEST_OK small_cases={} known_base={} known_hyperspace={} \
         lazy_hyperspace={} ultrametric_hyperspace={}",
        small_cases.len(),
        base,
        hyperspace,
        lazy_hyperspace,
        ultrametric_hyperspace,
    );
    Ok(())
}

fn half_integer(value: u32) -> String {
    if value.is_multiple_of(2) {
        (value / 2).to_string()
    } else {
        format!("{}.5", value / 2)
    }
}

fn run(arguments: Arguments) -> Result<(), String> {
    if arguments.self_test {
        run_self_test()?;
    }

    let requested_pair = if arguments.known_pair {
        Some((
            Metric::from_edges(&KNOWN_LEFT)?,
            Metric::from_edges(&KNOWN_RIGHT)?,
        ))
    } else if let (Some(left_family), Some(right_family), Some(order)) = (
        arguments.left_family,
        arguments.right_family,
        arguments.order,
    ) {
        Some((
            family_metric(&left_family, order)?,
            family_metric(&right_family, order)?,
        ))
    } else {
        arguments
            .left_edges
            .zip(arguments.right_edges)
            .map(|(left, right)| {
                Ok::<(Metric, Metric), String>((
                    Metric::from_edges(&left)?,
                    Metric::from_edges(&right)?,
                ))
            })
            .transpose()?
    };
    let Some((left, right)) = requested_pair else {
        if arguments.self_test {
            return Ok(());
        }
        return Err(format!(
            "choose --known-pair or provide explicit edges\n{}",
            usage()
        ));
    };

    let base_left_order = left.order;
    let base_right_order = right.order;
    let total_started = Instant::now();
    let explicit_engine = !arguments.hyperspace || matches!(arguments.engine, EngineMode::Explicit);
    if explicit_engine {
        let (search_left, search_right, layer) = if arguments.hyperspace {
            (
                hyperspace_metric(&left, arguments.max_hyperspace_points)?,
                hyperspace_metric(&right, arguments.max_hyperspace_points)?,
                "hyperspace",
            )
        } else {
            (left, right, "base")
        };
        let metric_setup_elapsed = total_started.elapsed();
        let search_started = Instant::now();
        let (distortion, stats) =
            minimum_distortion(&search_left, &search_right, arguments.max_relation_vertices)?;
        let search_elapsed = search_started.elapsed();
        let total_elapsed = total_started.elapsed();
        println!(
            "EXACT_RESULT layer={} engine=explicit base_orders={}x{} search_orders={}x{} \
             relation_vertices={} distortion={} d_GH={} candidate_thresholds={} \
             feasibility_checks={} search_nodes={} compatibility_masks_built={} \
             memo_hits={} failed_states={} metric_setup_ms={:.3} search_ms={:.3} \
             total_ms={:.3}",
            layer,
            base_left_order,
            base_right_order,
            search_left.order,
            search_right.order,
            search_left.order * search_right.order,
            distortion,
            half_integer(distortion),
            stats.candidate_thresholds,
            stats.feasibility_checks,
            stats.search_nodes,
            stats.compatibility_masks_built,
            stats.memo_hits,
            stats.failed_states,
            metric_setup_elapsed.as_secs_f64() * 1_000.0,
            search_elapsed.as_secs_f64() * 1_000.0,
            total_elapsed.as_secs_f64() * 1_000.0,
        );
    } else {
        let strategy = match arguments.engine {
            EngineMode::Auto | EngineMode::Lazy => LazyStrategy::Auto,
            EngineMode::LazyGeneric => LazyStrategy::Generic,
            EngineMode::Ultrametric => LazyStrategy::Ultrametric,
            EngineMode::Z3 => LazyStrategy::Z3,
            EngineMode::Explicit => unreachable!(),
        };
        let engine_name = match strategy {
            LazyStrategy::Auto => "lazy-auto",
            LazyStrategy::Generic => "lazy-generic",
            LazyStrategy::Ultrametric => "ultrametric",
            LazyStrategy::Z3 => "z3",
        };
        let base_distortion = if arguments.compare_base {
            Some(minimum_distortion(&left, &right, arguments.max_relation_vertices)?.0)
        } else {
            None
        };
        let (distortion, stats) = minimum_hyperspace_distortion_lazy(
            &left,
            &right,
            &arguments.lazy_config,
            strategy,
            base_distortion,
        )?;
        if base_distortion.is_some_and(|base| distortion > base) {
            return Err("lazy hyperspace result exceeds its lifted base upper bound".to_string());
        }
        let base_report = base_distortion
            .map(|value| value.to_string())
            .unwrap_or_else(|| "not-computed".to_string());
        let comparison_report = base_distortion
            .map(|value| {
                if value == distortion {
                    "equal"
                } else {
                    "strictly-smaller"
                }
            })
            .unwrap_or("not-computed");
        let total_elapsed = total_started.elapsed();
        println!(
            "EXACT_RESULT layer=hyperspace engine={} base_orders={}x{} \
             search_orders={}x{} implicit_relation_vertices={} distortion={} d_GH={} \
             candidate_thresholds={} feasibility_checks={} generic_checks={} \
             ultrametric_checks={} ultrametric_fallbacks={} structural_rejections={} \
             dominance_rejections={} lazy_nodes={} candidate_scans={} \
             compatibility_checks={} lazy_memo_hits={} max_depth={} ultrametric_calls={} \
             ultrametric_assignments={} ultrametric_max_blocks={} distance_queries={} \
             distance_cache_hits={} dilation_tests={} z3_checks={} z3_fallbacks={} \
             z3_variables={} z3_clauses={} base_distortion={} comparison={} \
             total_ms={:.3}",
            engine_name,
            base_left_order,
            base_right_order,
            (1_usize << base_left_order) - 1,
            (1_usize << base_right_order) - 1,
            ((1_u128 << base_left_order) - 1) * ((1_u128 << base_right_order) - 1),
            distortion,
            half_integer(distortion),
            stats.candidate_thresholds,
            stats.feasibility_checks,
            stats.generic_checks,
            stats.ultrametric_checks,
            stats.ultrametric_fallbacks,
            stats.structural.lower_bound_rejections
                + stats.structural.cardinality_rejections
                + stats.structural.component_count_rejections
                + stats.structural.component_dominance_rejections,
            stats.structural.component_dominance_rejections,
            stats.lazy_search_nodes,
            stats.candidate_scans,
            stats.compatibility_checks,
            stats.lazy_memo_hits,
            stats.maximum_depth,
            stats.ultrametric_recursive_calls,
            stats.ultrametric_assignment_candidates,
            stats.ultrametric_maximum_block_count,
            stats.left_dilation.distance_queries + stats.right_dilation.distance_queries,
            stats.left_dilation.distance_cache_hits + stats.right_dilation.distance_cache_hits,
            stats.left_dilation.dilation_tests + stats.right_dilation.dilation_tests,
            stats.z3_checks,
            stats.z3_fallbacks,
            stats.z3_variables,
            stats.z3_clauses,
            base_report,
            comparison_report,
            total_elapsed.as_secs_f64() * 1_000.0,
        );
    }
    Ok(())
}

fn main() -> ExitCode {
    match parse_arguments().and_then(run) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("ERROR: {error}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exact_solver_matches_brute_force_on_small_cases() {
        let cases = [
            (vec![1], vec![3]),
            (vec![2], vec![2, 3, 4]),
            (vec![2, 3, 4], vec![3, 4, 5]),
        ];
        for (left_edges, right_edges) in cases {
            let left = Metric::from_edges(&left_edges).unwrap();
            let right = Metric::from_edges(&right_edges).unwrap();
            let (exact, _) =
                minimum_distortion(&left, &right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
            let brute = brute_force_minimum_distortion(&left, &right).unwrap();
            assert_eq!(exact, brute);
        }
    }

    #[test]
    fn every_small_three_point_lazy_result_matches_explicit_search() {
        let mut metrics = Vec::new();
        for a in 1..=4 {
            for b in 1..=4 {
                for c in 1..=4 {
                    if let Ok(metric) = Metric::from_edges(&[a, b, c]) {
                        metrics.push(metric);
                    }
                }
            }
        }
        for left_index in 0..metrics.len() {
            for right_index in left_index..metrics.len() {
                let left = &metrics[left_index];
                let right = &metrics[right_index];
                let exp_left = hyperspace_metric(left, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
                let exp_right = hyperspace_metric(right, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
                let (explicit, _) =
                    minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES)
                        .unwrap();
                let (generic, _) = minimum_hyperspace_distortion_lazy(
                    left,
                    right,
                    &LazyConfig::default(),
                    LazyStrategy::Generic,
                    None,
                )
                .unwrap();
                assert_eq!(generic, explicit, "left={left:?}, right={right:?}");
                if left.is_ultrametric() && right.is_ultrametric() {
                    let (decomposed, _) = minimum_hyperspace_distortion_lazy(
                        left,
                        right,
                        &LazyConfig::default(),
                        LazyStrategy::Ultrametric,
                        None,
                    )
                    .unwrap();
                    assert_eq!(
                        decomposed, explicit,
                        "ultrametric left={left:?}, right={right:?}"
                    );
                }
            }
        }
    }

    #[test]
    fn known_four_point_pair_matches_python_oracle() {
        let left = Metric::from_edges(&KNOWN_LEFT).unwrap();
        let right = Metric::from_edges(&KNOWN_RIGHT).unwrap();
        let (base, _) = minimum_distortion(&left, &right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
        assert_eq!(base, 484);
        assert_eq!(base, brute_force_minimum_distortion(&left, &right).unwrap());

        let exp_left = hyperspace_metric(&left, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
        let exp_right = hyperspace_metric(&right, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
        let (hyperspace, _) =
            minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
        assert_eq!(hyperspace, 484);
        let (lazy, _) = minimum_hyperspace_distortion_lazy(
            &left,
            &right,
            &LazyConfig::default(),
            LazyStrategy::Generic,
            None,
        )
        .unwrap();
        assert_eq!(lazy, hyperspace);
        let (automatic, automatic_stats) = minimum_hyperspace_distortion_lazy(
            &left,
            &right,
            &LazyConfig::default(),
            LazyStrategy::Auto,
            Some(base),
        )
        .unwrap();
        assert_eq!(automatic, hyperspace);
        assert_eq!(automatic_stats.z3_checks, 0);
    }

    #[test]
    fn dilation_oracle_matches_every_explicit_small_hyperspace_distance() {
        let metrics = [
            Metric::from_edges(&[2, 3, 4]).unwrap(),
            Metric::from_edges(&[2, 4, 8, 4, 8, 8]).unwrap(),
            Metric::from_edges(&KNOWN_LEFT).unwrap(),
        ];
        for base in metrics {
            let explicit = hyperspace_metric(&base, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
            let mut oracle = HausdorffOracle::new(&base, 10_000).unwrap();
            for left in 1..=oracle.point_count() as u64 {
                for right in 1..=oracle.point_count() as u64 {
                    assert_eq!(
                        oracle.distance(left, right),
                        explicit.get(left as usize - 1, right as usize - 1),
                        "base={base:?}, subsets={left:b},{right:b}"
                    );
                }
            }
        }
    }

    #[test]
    fn ultrametric_decomposition_matches_explicit_hyperspace_search() {
        let cases = [
            (
                Metric::from_edges(&[1, 1, 2, 1, 2, 2]).unwrap(),
                Metric::from_edges(&[2, 3, 3, 3, 3, 2]).unwrap(),
            ),
            (
                Metric::from_edges(&[1, 2, 2, 2, 2, 1]).unwrap(),
                Metric::from_edges(&[1, 1, 3, 1, 3, 3]).unwrap(),
            ),
        ];
        for (left, right) in cases {
            assert!(left.is_ultrametric() && right.is_ultrametric());
            let exp_left = hyperspace_metric(&left, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
            let exp_right = hyperspace_metric(&right, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
            let (explicit, _) =
                minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
            let (decomposed, _) = minimum_hyperspace_distortion_lazy(
                &left,
                &right,
                &LazyConfig::default(),
                LazyStrategy::Ultrametric,
                None,
            )
            .unwrap();
            assert_eq!(decomposed, explicit);
        }
    }

    #[test]
    fn all_four_point_ultrametric_types_through_level_three_match_explicit_search() {
        fn canonical_four_point_key(metric: &Metric) -> Vec<u32> {
            let mut best: Option<Vec<u32>> = None;
            for a in 0..4 {
                for b in 0..4 {
                    for c in 0..4 {
                        for d in 0..4 {
                            let permutation = [a, b, c, d];
                            let distinct = (0..4)
                                .all(|i| ((i + 1)..4).all(|j| permutation[i] != permutation[j]));
                            if !distinct {
                                continue;
                            }
                            let mut key = Vec::with_capacity(6);
                            for i in 0..4 {
                                for j in (i + 1)..4 {
                                    key.push(metric.get(permutation[i], permutation[j]));
                                }
                            }
                            if best.as_ref().is_none_or(|current| key < *current) {
                                best = Some(key);
                            }
                        }
                    }
                }
            }
            best.unwrap()
        }

        let mut representatives = BTreeMap::new();
        for encoded in 0_u32..3_u32.pow(6) {
            let mut cursor = encoded;
            let mut edges = [0_u32; 6];
            for edge in &mut edges {
                *edge = cursor % 3 + 1;
                cursor /= 3;
            }
            if let Ok(metric) = Metric::from_edges(&edges)
                && metric.is_ultrametric()
            {
                representatives
                    .entry(canonical_four_point_key(&metric))
                    .or_insert(metric);
            }
        }
        let metrics: Vec<Metric> = representatives.into_values().collect();
        assert_eq!(metrics.len(), 14);
        for left_index in 0..metrics.len() {
            for right_index in (left_index + 1)..metrics.len() {
                let left = &metrics[left_index];
                let right = &metrics[right_index];
                let exp_left = hyperspace_metric(left, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
                let exp_right = hyperspace_metric(right, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
                let (explicit, _) =
                    minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES)
                        .unwrap();
                let (decomposed, _) = minimum_hyperspace_distortion_lazy(
                    left,
                    right,
                    &LazyConfig::default(),
                    LazyStrategy::Ultrametric,
                    None,
                )
                .unwrap();
                assert_eq!(decomposed, explicit, "left={left:?}, right={right:?}");
            }
        }
    }

    #[test]
    fn structural_filter_accepts_certified_hyperspace_optima() {
        let cases = [
            (
                Metric::from_edges(&KNOWN_LEFT).unwrap(),
                Metric::from_edges(&KNOWN_RIGHT).unwrap(),
            ),
            (
                Metric::from_edges(&[1, 1, 2, 1, 2, 2]).unwrap(),
                Metric::from_edges(&[2, 3, 3, 3, 3, 2]).unwrap(),
            ),
        ];
        for (left, right) in cases {
            let exp_left = hyperspace_metric(&left, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
            let exp_right = hyperspace_metric(&right, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
            let (optimum, _) =
                minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
            assert!(StructuralFilter::new(&left, &right).accepts(optimum));
        }
    }

    #[test]
    fn equilateral_lazy_formula_matches_unequal_explicit_cardinalities() {
        let left = Metric::from_edges(&[2]).unwrap();
        let right = Metric::from_edges(&[3, 3, 3]).unwrap();
        let exp_left = hyperspace_metric(&left, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
        let exp_right = hyperspace_metric(&right, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
        let (explicit, _) =
            minimum_distortion(&exp_left, &exp_right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
        let (lazy, _) = minimum_hyperspace_distortion_lazy(
            &left,
            &right,
            &LazyConfig::default(),
            LazyStrategy::Auto,
            None,
        )
        .unwrap();
        assert_eq!(lazy, explicit);
    }

    #[test]
    fn order_twenty_identity_uses_no_explicit_hyperspace() {
        let metric = family_metric("comb_ultrametric", 20).unwrap();
        let (distortion, stats) = minimum_hyperspace_distortion_lazy(
            &metric,
            &metric,
            &LazyConfig::default(),
            LazyStrategy::Auto,
            None,
        )
        .unwrap();
        assert_eq!(distortion, 0);
        assert_eq!(stats.left_dilation.distance_queries, 0);
        assert_eq!(stats.right_dilation.distance_queries, 0);
    }

    #[test]
    fn optional_z3_backend_resolves_a_hard_five_point_threshold() {
        if Command::new("z3").arg("-version").output().is_err() {
            return;
        }
        let left = family_metric("rank_generic", 5).unwrap();
        let right = family_metric("dyadic_line", 5).unwrap();
        let (base, _) = minimum_distortion(&left, &right, DEFAULT_MAX_RELATION_VERTICES).unwrap();
        let (hyperspace, stats) = minimum_hyperspace_distortion_lazy(
            &left,
            &right,
            &LazyConfig::default(),
            LazyStrategy::Z3,
            Some(base),
        )
        .unwrap();
        assert_eq!(hyperspace, base);
        assert!(stats.z3_checks > 0);
    }

    #[test]
    fn two_point_hyperspace_is_equilateral() {
        let base = Metric::from_edges(&[7]).unwrap();
        let hyperspace = hyperspace_metric(&base, DEFAULT_MAX_HYPERSPACE_POINTS).unwrap();
        assert_eq!(hyperspace.order, 3);
        assert_eq!(hyperspace.distance_levels(), BTreeSet::from([0, 7]));
    }

    #[test]
    fn every_recorded_family_builds_through_order_twenty() {
        for family in [
            "equilateral",
            "binary_star",
            "dyadic_line",
            "comb_ultrametric",
            "balanced_ultrametric",
            "rank_generic",
        ] {
            for order in 4..=20 {
                assert_eq!(family_metric(family, order).unwrap().order, order);
            }
        }
    }
}
